cd api
npm i create-react-app express config bcrypt concurrently nodemon pg-promise nodemailer
cd ../client
npm i bootstrap react-router-dom jquery reactstrap