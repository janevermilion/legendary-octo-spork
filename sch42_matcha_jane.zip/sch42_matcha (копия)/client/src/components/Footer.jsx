import React from 'react';
import { Container } from 'reactstrap';

function Footer(props) {
    return (
        <div className="footer bg-light">
            <Container>
                <h2>footer</h2>
            </Container>
        </div>
    )
}

export default Footer;
