export const PROFILE_ADD = 'PROFILE_ADD';
export const PROFILE_LOADING = 'PROFILE_LOADING';
export const PROFILE_FAILED = 'PROFILE_FAILED';
export const VIEW_ADD = 'VIEW_ADD';
export const VIEW_FAILED = 'VIEW_FAILED';
export const LIKE_ADD = 'LIKE_ADD';
export const LIKE_FAILED = 'LIKE_FAILED';

